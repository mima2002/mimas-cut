document.addEventListener("DOMContentLoaded", () => {
  // Mobile menu toggle
  const menuBtn = document.getElementById("menu-btn");
  const menu = document.getElementById("menu");
  menuBtn.addEventListener("click", () => {
    menu.classList.toggle("hidden");
  });

  // Typing effect
  function typeWriter(elementId, text, speed = 100, callback) {
    let i = 0;
    function typing() {
      if (i < text.length) {
        document.getElementById(elementId).innerHTML = text.substring(0, i + 1) + '<span class="border-r-2 border-green-600 animate-pulse">|</span>';
        i++;
        setTimeout(typing, speed);
      } else {
        document.getElementById(elementId).innerHTML = text; // remove cursor when done
        if (callback) callback();
      }
    }
    typing();
  }

  typeWriter("typingText1", "UI/UX Designer & Frontend Developer", 80, () => {
    typeWriter("typingText2", "I bridge the gap between design and development.", 50);
  });
});
